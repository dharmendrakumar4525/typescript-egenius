export enum TextType {
    header = 'Student Profiling',
    subHeader1='Primary Information',
    subHeader2='Contact Details',
    subHeader3='Correspondance Address',
    subHeader4='Permanent Address',
    subHeader5='Admission Details',
    subHeader6='Supporting Documents References',
    success = 'success',
    error = 'error'

}